package pres;

import javax.swing.*;
import java.awt.*;

public class SevenSegmentDigit
    extends JPanel {

    private int number;
    private int x;
    private int y;
    private SevenSegmentDigit nextDigit;
    private static ImageRenderer ir = new ImageRenderer();

    public SevenSegmentDigit(int number, int x, int y, SevenSegmentDigit nextDigit) {
        this.number = number;
        this.x = x;
        this.y = y;
        this.nextDigit = nextDigit;
        setOpaque(false);

        ir.addImage(0, "src\\digits\\0.png");
        ir.addImage(1, "src\\digits\\1.png");
        ir.addImage(2, "src\\digits\\2.png");
        ir.addImage(3, "src\\digits\\3.png");
        ir.addImage(4, "src\\digits\\4.png");
        ir.addImage(5, "src\\digits\\5.png");
        ir.addImage(6, "src\\digits\\6.png");
        ir.addImage(7, "src\\digits\\7.png");
        ir.addImage(8, "src\\digits\\8.png");
        ir.addImage(9, "src\\digits\\9.png");
    }

    public SevenSegmentDigit(int number, int x, int y){
        this.number = number;
        this.x = x;
        this.y = y;
        setOpaque(false);
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    public void StartEvent(){
        this.number = 0;
    }

    public void PlusOneEvent(){
        if(this.number == 9){
            if(nextDigit.getNumber() == -1) nextDigit.setNumber(0);
            nextDigit.PlusOneEvent();
            this.number = -1;
        }

        this.number += 1;
    }

    public void ResetEvent(){
        this.number = -1;
        if(nextDigit != null) this.nextDigit.ResetEvent();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if(number >= 0 && number <= 9){
            Image img = ir.imageMap.get(number).getImage();
            if(img != null){
                g.drawImage(img, x, y, this);
            }
        }
    }
}
