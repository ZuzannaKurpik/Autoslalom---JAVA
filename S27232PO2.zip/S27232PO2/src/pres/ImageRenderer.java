package pres;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class ImageRenderer extends DefaultTableCellRenderer {
    JLabel lbl = new JLabel();
    Map<Object, ImageIcon> imageMap = new HashMap<>();

    public void addImage(Object cellValue, String imagePath) {
        imageMap.put(cellValue, new ImageIcon(imagePath));
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        ImageIcon icon = imageMap.get(value);
        if (icon != null) {
            lbl.setIcon(icon);
        } else {
            lbl.setIcon(null);
        }
        return lbl;
    }
}