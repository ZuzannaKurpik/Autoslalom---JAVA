package pres;

import game.Board;
import game.BoardListner;
import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class Game
        extends JPanel
        implements BoardListner {

    public static JTable table;
    private static Board board;
    private static ImageRenderer ir = new ImageRenderer();
    private static SevenSegmentDigit ssd1;
    private static SevenSegmentDigit ssd2;
    private static SevenSegmentDigit ssd3;
    private static int linesCounter = 0;
    private static boolean isRunning = true;

    public Game() {
        JLayeredPane layeredPane = new JLayeredPane();

        setLayout(new BorderLayout());
        add(layeredPane, BorderLayout.CENTER);

        table = new JTable(7, 1);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setBounds(114, 70, 173, 110);
        table.setRowHeight(6, 32);
        table.setRowHeight(5, 9);
        table.setRowHeight(4, 14);
        table.setRowHeight(3, 14);
        table.setRowHeight(2, 15);
        table.setRowHeight(1, 11);
        table.setRowHeight(0, 15);
        table.setVisible(true);
        addingImages();
        table.getColumnModel().getColumn(0).setCellRenderer(ir);
        layeredPane.add(table, JLayeredPane.FRAME_CONTENT_LAYER);

        ssd3 = new SevenSegmentDigit(-1, 120,75);
        ssd2 = new SevenSegmentDigit(-1, 140,75, ssd3);
        ssd1 = new SevenSegmentDigit(0, 160, 75, ssd2);

        ssd1.setOpaque(false);
        ssd2.setOpaque(false);
        ssd3.setOpaque(false);

        ssd1.setBounds(0, 0, 415, 280);
        ssd2.setBounds(0, 0, 415, 280);
        ssd3.setBounds(0, 0, 415, 280);

        layeredPane.add(ssd1, JLayeredPane.POPUP_LAYER);
        layeredPane.add(ssd2, JLayeredPane.POPUP_LAYER);
        layeredPane.add(ssd3, JLayeredPane.POPUP_LAYER);

        board = new Board();
        board.setBoardListner(this);
        this.setFocusable(true);
        this.requestFocusInWindow();
        this.addKeyListener(board);
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        ImageIcon obwod = new ImageIcon("src\\zdjecia\\obwod.jpg");
        Image obwodImage = obwod.getImage();
        g.drawImage(obwodImage, 0, 0, this);
        boolean linesForCar = false;
        int oldLineCounter = linesCounter;

        for(int i=0; i<7; i++){
            String index = String.valueOf((6-i));
            int pozycja = Board.tor[6-i];
            String pozycjaBity = Board.odczytBitowy(pozycja);

            for(Map.Entry<Object, ImageIcon> entry : ir.imageMap.entrySet()){
                Object key = entry.getKey();
                String keyString = (String) key;
                String[] parts = keyString.split("_");

                if (linesCounter % 3 != 0){
                    if (parts[0].equals(pozycjaBity) && parts[1].equals(index) && !keyString.endsWith("L")) {
                        table.setValueAt(key, i, 0);

                        if(i == 5)linesForCar = false;
                    }
                }else{
                    if (parts[0].equals(pozycjaBity) && parts[1].equals(index) && keyString.endsWith("L")) {
                        table.setValueAt(key, i, 0);

                        if(i == 5)linesForCar = true;
                    }
                }

                if (linesForCar && parts[1].equals(pozycjaBity) && parts[0].equals("car") && keyString.endsWith("L")) {
                    table.setValueAt(key, 6, 0);
                }else if (!linesForCar && parts[1].equals(pozycjaBity) && parts[0].equals("car") && !keyString.endsWith("L")) {
                    table.setValueAt(key, 6, 0);
                }
            }
            linesCounter++;
        }
        linesCounter = oldLineCounter;
    }

    @Override
    public void onCarPositionChanged() {
        repaint();
    }

    public static void startGame(){
        ssd1.StartEvent();
        isRunning = true;
        new Thread(() -> {
            int sleepingmode = 1300;
            while (isRunning){
                boolean collision = board.tickEvent();

                if(!collision && board.getObstacle() != 0 && board.getScore() != 999){
                    board.scorePlusOne();
                    ssd1.PlusOneEvent();
                }else if(collision || board.getScore() == 999){
                    ssd1.ResetEvent();
                    isRunning = false;
                }

                try{
                    Thread.sleep(sleepingmode);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
                sleepingmode -= 1;
                linesCounter -= 4;
            }
        }).start();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Autoslalom - po2");
        Game game = new Game();
        frame.add(game);
        frame.setSize(415, 280);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setVisible(true);
    }

    public static void addingImages(){
        // car
        ir.addImage("car_001_L", "src\\zdjecia\\car_001_L.jpg");
        ir.addImage("car_001", "src\\zdjecia\\car_001.jpg");
        ir.addImage("car_010_L", "src\\zdjecia\\car_010_L.jpg");
        ir.addImage("car_010", "src\\zdjecia\\car_010.jpg");
        ir.addImage("car_100_L", "src\\zdjecia\\car_100_L.jpg");
        ir.addImage("car_100", "src\\zdjecia\\car_100.jpg");

        // index1
        ir.addImage("000_1", "src\\zdjecia\\index1\\000_1.png");
        ir.addImage("000_1_L", "src\\zdjecia\\index1\\000_1_L.png");
        ir.addImage("001_1", "src\\zdjecia\\index1\\001_1.png");
        ir.addImage("001_1_L", "src\\zdjecia\\index1\\001_1_L.png");
        ir.addImage("010_1", "src\\zdjecia\\index1\\010_1.png");
        ir.addImage("010_1_L", "src\\zdjecia\\index1\\010_1_L.png");
        ir.addImage("011_1", "src\\zdjecia\\index1\\011_1.png");
        ir.addImage("011_1_L", "src\\zdjecia\\index1\\011_1_L.png");
        ir.addImage("100_1", "src\\zdjecia\\index1\\100_1.png");
        ir.addImage("100_1_L", "src\\zdjecia\\index1\\100_1_L.png");
        ir.addImage("101_1", "src\\zdjecia\\index1\\101_1.png");
        ir.addImage("101_1_L", "src\\zdjecia\\index1\\101_1_L.png");
        ir.addImage("110_1", "src\\zdjecia\\index1\\110_1.png");
        ir.addImage("110_1_L", "src\\zdjecia\\index1\\110_1_L.png");
        ir.addImage("111_1", "src\\zdjecia\\index1\\111_1.png");
        ir.addImage("111_1_L", "src\\zdjecia\\index1\\111_1_L.png");

        // index2
        ir.addImage("000_2", "src\\zdjecia\\index2\\000_2.png");
        ir.addImage("000_2_L", "src\\zdjecia\\index2\\000_2_L.png");
        ir.addImage("001_2", "src\\zdjecia\\index2\\001_2.png");
        ir.addImage("001_2_L", "src\\zdjecia\\index2\\001_2_L.png");
        ir.addImage("010_2", "src\\zdjecia\\index2\\010_2.png");
        ir.addImage("010_2_L", "src\\zdjecia\\index2\\010_2_L.png");
        ir.addImage("011_2", "src\\zdjecia\\index2\\011_2.png");
        ir.addImage("011_2_L", "src\\zdjecia\\index2\\011_2_L.png");
        ir.addImage("100_2", "src\\zdjecia\\index2\\100_2.png");
        ir.addImage("100_2_L", "src\\zdjecia\\index2\\100_2_L.png");
        ir.addImage("101_2", "src\\zdjecia\\index2\\101_2.png");
        ir.addImage("101_2_L", "src\\zdjecia\\index2\\101_2_L.png");
        ir.addImage("110_2", "src\\zdjecia\\index2\\110_2.png");
        ir.addImage("110_2_L", "src\\zdjecia\\index2\\110_2_L.png");
        ir.addImage("111_2", "src\\zdjecia\\index2\\111_2.png");
        ir.addImage("111_2_L", "src\\zdjecia\\index2\\111_2_L.png");

        // index3
        ir.addImage("000_3", "src\\zdjecia\\index3\\000_3.png");
        ir.addImage("000_3_L", "src\\zdjecia\\index3\\000_3_L.png");
        ir.addImage("001_3", "src\\zdjecia\\index3\\001_3.png");
        ir.addImage("001_3_L", "src\\zdjecia\\index3\\001_3_L.png");
        ir.addImage("010_3", "src\\zdjecia\\index3\\010_3.png");
        ir.addImage("010_3_L", "src\\zdjecia\\index3\\010_3_L.png");
        ir.addImage("011_3", "src\\zdjecia\\index3\\011_3.png");
        ir.addImage("011_3_L", "src\\zdjecia\\index3\\011_3_L.png");
        ir.addImage("100_3", "src\\zdjecia\\index3\\100_3.png");
        ir.addImage("100_3_L", "src\\zdjecia\\index3\\100_3_L.png");
        ir.addImage("101_3", "src\\zdjecia\\index3\\101_3.png");
        ir.addImage("101_3_L", "src\\zdjecia\\index3\\101_3_L.png");
        ir.addImage("110_3", "src\\zdjecia\\index3\\110_3.png");
        ir.addImage("110_3_L", "src\\zdjecia\\index3\\110_3_L.png");
        ir.addImage("111_3", "src\\zdjecia\\index3\\111_3.png");
        ir.addImage("111_3_L", "src\\zdjecia\\index3\\111_3_L.png");

        // index4
        ir.addImage("000_4", "src\\zdjecia\\index4\\000_4.png");
        ir.addImage("000_4_L", "src\\zdjecia\\index4\\000_4_L.png");
        ir.addImage("001_4", "src\\zdjecia\\index4\\001_4.png");
        ir.addImage("001_4_L", "src\\zdjecia\\index4\\001_4_L.png");
        ir.addImage("010_4", "src\\zdjecia\\index4\\010_4.png");
        ir.addImage("010_4_L", "src\\zdjecia\\index4\\010_4_L.png");
        ir.addImage("011_4", "src\\zdjecia\\index4\\011_4.png");
        ir.addImage("011_4_L", "src\\zdjecia\\index4\\011_4_L.png");
        ir.addImage("100_4", "src\\zdjecia\\index4\\100_4.png");
        ir.addImage("100_4_L", "src\\zdjecia\\index4\\100_4_L.png");
        ir.addImage("101_4", "src\\zdjecia\\index4\\101_4.png");
        ir.addImage("101_4_L", "src\\zdjecia\\index4\\101_4_L.png");
        ir.addImage("110_4", "src\\zdjecia\\index4\\110_4.png");
        ir.addImage("110_4_L", "src\\zdjecia\\index4\\110_4_L.png");
        ir.addImage("111_4", "src\\zdjecia\\index4\\111_4.png");
        ir.addImage("111_4_L", "src\\zdjecia\\index4\\111_4_L.png");

        // index5
        ir.addImage("000_5", "src\\zdjecia\\index5\\000_5.png");
        ir.addImage("000_5_L", "src\\zdjecia\\index5\\000_5_L.png");
        ir.addImage("001_5", "src\\zdjecia\\index5\\001_5.png");
        ir.addImage("001_5_L", "src\\zdjecia\\index5\\001_5_L.png");
        ir.addImage("010_5", "src\\zdjecia\\index5\\010_5.png");
        ir.addImage("010_5_L", "src\\zdjecia\\index5\\010_5_L.png");
        ir.addImage("011_5", "src\\zdjecia\\index5\\011_5.png");
        ir.addImage("011_5_L", "src\\zdjecia\\index5\\011_5_L.png");
        ir.addImage("100_5", "src\\zdjecia\\index5\\100_5.png");
        ir.addImage("100_5_L", "src\\zdjecia\\index5\\100_5_L.png");
        ir.addImage("101_5", "src\\zdjecia\\index5\\101_5.png");
        ir.addImage("101_5_L", "src\\zdjecia\\index5\\101_5_L.png");
        ir.addImage("110_5", "src\\zdjecia\\index5\\110_5.png");
        ir.addImage("110_5_L", "src\\zdjecia\\index5\\110_5_L.png");
        ir.addImage("111_5", "src\\zdjecia\\index5\\111_5.png");
        ir.addImage("111_5_L", "src\\zdjecia\\index5\\111_5_L.png");

        // index6
        ir.addImage("000_6", "src\\zdjecia\\index6\\000_6.png");
        ir.addImage("000_6_L", "src\\zdjecia\\index6\\000_6_L.png");
        ir.addImage("001_6", "src\\zdjecia\\index6\\001_6.png");
        ir.addImage("001_6_L", "src\\zdjecia\\index6\\001_6_L.png");
        ir.addImage("010_6", "src\\zdjecia\\index6\\010_6.png");
        ir.addImage("010_6_L", "src\\zdjecia\\index6\\010_6_L.png");
        ir.addImage("011_6", "src\\zdjecia\\index6\\011_6.png");
        ir.addImage("011_6_L", "src\\zdjecia\\index6\\011_6_L.png");
        ir.addImage("100_6", "src\\zdjecia\\index6\\100_6.png");
        ir.addImage("100_6_L", "src\\zdjecia\\index6\\100_6_L.png");
        ir.addImage("101_6", "src\\zdjecia\\index6\\101_6.png");
        ir.addImage("101_6_L", "src\\zdjecia\\index6\\101_6_L.png");
        ir.addImage("110_6", "src\\zdjecia\\index6\\110_6.png");
        ir.addImage("110_6_L", "src\\zdjecia\\index6\\110_6_L.png");
        ir.addImage("111_6", "src\\zdjecia\\index6\\111_6.png");
        ir.addImage("111_6_L", "src\\zdjecia\\index6\\111_6_L.png");
    }

}
