package game;

import pres.Game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class Board implements KeyListener {
    public static int[] tor = new int[7];
    private static int obstacleFrequency = 3;
    private static int score = 0;
    private static Random rand;
    private int obstacle = 0;
    private BoardListner listner;

    public Board(){
        tor[0] = 2;
        rand = new Random();
        if(listner != null) listner.onCarPositionChanged();
    }

    public void setBoardListner(BoardListner boardListner){
        this.listner = boardListner;
    }

    public void scorePlusOne(){
        score += 1;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_A:
                moveCarLeft();
                break;
            case KeyEvent.VK_D:
                moveCarRight();
                break;
            case KeyEvent.VK_S:
                int wartosc = 0;
                for(int i=1; i<tor.length; i++){
                    wartosc = wstawNowaWartosc(tor[i-1]);
                    tor[i] = wartosc;
                }
                Game.startGame();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    public void moveCarRight(){
        if(tor[0] == 4) tor[0] = 2;
        else if (tor[0] == 2) tor[0] = 1;

        if(listner != null) listner.onCarPositionChanged();
    }

    public void moveCarLeft(){
        if(tor[0] == 1) tor[0] = 2;
        else if (tor[0] == 2) tor[0] = 4;

        if(listner != null) listner.onCarPositionChanged();
    }

    public static int losowanieLiczby(){
        return 1 + rand.nextInt(6);
    }

    public int[] dynamicznaTablica(int[] tor, int koncowaWartosc){
        int carPosition = tor[0];
        this.obstacle = tor[1];
        int[] newTabela = new int[7];
        for(int i = 1; i<6; i++){
            newTabela[i] = tor[i+1];
        }
        newTabela[0] = carPosition;
        newTabela[6] = koncowaWartosc;
        return newTabela;
    }

    public static String odczytBitowy(int cyfra){
        String binaryString = Integer.toBinaryString(cyfra);
        while (binaryString.length() < 3){
            binaryString = "0" + binaryString;
        }
        return binaryString;
    }

    public static int wstawNowaWartosc(int wartoscPrzeszkody){
        int cyfra = 0;
        boolean done = false;
        String scoreString = String.valueOf(score);
        String przeszkoda = odczytBitowy(wartoscPrzeszkody);
        while (!done){
            cyfra = losowanieLiczby();
            String nowaLiczba = odczytBitowy(cyfra);

            boolean niePasuje = false;
            if(obstacleFrequency == 0){
                for (int i = 0; i < 3; i++) {
                    if (nowaLiczba.charAt(i) == przeszkoda.charAt(i) && nowaLiczba.charAt(i) == '1') {
                        niePasuje = true;
                        break;
                    }
                }

                if(niePasuje == false){
                    done = true;
                }

                if(scoreString.length() == 1) obstacleFrequency = 2;
                else if(scoreString.length() == 2) obstacleFrequency = 1;

            }else {
                done = true;
                cyfra = 0;
            }
        }
        if(scoreString.length() != 3 && obstacleFrequency != 0) obstacleFrequency--;
        return cyfra;
    }

    private boolean checkCollision(){
        String samochod = odczytBitowy(tor[0]);
        String przeszkoda = odczytBitowy(obstacle);
        for (int i = 0; i < 3; i++) {
            if(samochod.charAt(i) == przeszkoda.charAt(i) && samochod.charAt(i) == '1'){
                resetGame();
                return true;
            }
        }
        return false;
    }

    private void resetGame(){
        tor = new int[7];
        tor[0] = 2;
        obstacleFrequency = 4;
    }

    public boolean tickEvent(){
        int wartosc = wstawNowaWartosc(tor[6]);
        tor = dynamicznaTablica(tor, wartosc);
        if(listner != null) listner.onCarPositionChanged();
        return checkCollision();
    }

    public int getScore() {
        return score;
    }

    public int getObstacle() {
        return obstacle;
    }

}
