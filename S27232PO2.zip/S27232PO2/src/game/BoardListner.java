package game;

public interface BoardListner {
    void onCarPositionChanged();
}
